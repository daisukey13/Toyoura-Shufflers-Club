// lib/supabase-server.ts
import { createClient } from '@supabase/supabase-js';

export const supabaseServer = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, // 公開記事の閲覧だけなので anon でOK
  { auth: { persistSession: false, autoRefreshToken: false } }
);
